// Update Asset resources.
	
	updateAsset(assignment, serviceContext);

	return assignment;
}
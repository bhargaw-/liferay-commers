"com.liferay.portlet.css-class-wrapper=gradebook-portlet",
"com.liferay.portlet.header-portlet-css=/css/main.css",
compileOnly group: "com.liferay", name: "com.liferay.asset.api"
compileOnly group: "com.liferay", name: "com.liferay.asset.display.page.api"
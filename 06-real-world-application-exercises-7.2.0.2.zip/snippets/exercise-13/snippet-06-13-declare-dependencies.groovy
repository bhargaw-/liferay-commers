compileOnly group: "com.liferay", name: "com.liferay.portal.search.spi"
compileOnly group: "com.liferay", name: "com.liferay.portal.search.api"
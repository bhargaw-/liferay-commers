package com.liferay.training.deployment.api;

public interface FailingApi {
	
	void printMessage();
}


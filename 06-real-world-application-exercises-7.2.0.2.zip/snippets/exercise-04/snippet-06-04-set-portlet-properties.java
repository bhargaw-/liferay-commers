"com.liferay.portlet.display-category=category.training",
"com.liferay.portlet.instanceable=false",

// Update asset resources.

	updateAsset(assignment, serviceContext);

	return assignment;
}
package com.liferay.training.deployment.formatter;

public interface StringFormatter {
	
	public String getString();

}

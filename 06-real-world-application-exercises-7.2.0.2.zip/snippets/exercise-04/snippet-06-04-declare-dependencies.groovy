compileOnly group: 'com.liferay', name: 'com.liferay.petra.function'
compileOnly group: 'com.liferay', name: 'com.liferay.frontend.taglib.clay'
compileOnly project(":modules:gradebook:gradebook-api")
@Reference
protected MailService _mailService;

@Reference
protected UserService _userService;
@Override
public Assignment addAssignment(Assignment assignment) {
	throw new UnsupportedOperationException("Not supported.");
}

@Override
public Assignment updateAssignment(Assignment assignment) {
	throw new UnsupportedOperationException(
			"Not supported.");
}
package com.liferay.training.deployment.reference;

public interface FailingServiceReference {
	
	public String getStatus();

}
